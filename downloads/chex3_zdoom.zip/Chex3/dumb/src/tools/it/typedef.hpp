typedef unsigned char byte;
typedef unsigned short word;
typedef unsigned int dword;
