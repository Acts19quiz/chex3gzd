class AActor;

/*
void A_NoBlocking (AActor *);
void A_HideThing (AActor *);
void A_UnHideThing (AActor *);
void A_FreezeDeath (AActor *);
void A_FreezeDeathChunks (AActor *);
void A_GenericFreezeDeath (AActor *);
void A_IceSetTics (AActor *);
void A_IceCheckHeadDone (AActor *);
void A_QueueCorpse (AActor *);
void A_DeQueueCorpse (AActor *);
void A_SetInvulnerable (AActor *);
void A_UnSetInvulnerable (AActor *);
void A_SetReflective (AActor *);
void A_UnSetReflective (AActor *);
void A_SetReflectiveInvulnerable (AActor *);
void A_UnSetReflectiveInvulnerable (AActor *);
void A_SetShootable (AActor *);
void A_UnSetShootable (AActor *);
void A_SetFloorClip (AActor *);
void A_UnSetFloorClip (AActor *);
void A_NoGravity (AActor *);
void A_SkullPop (AActor *);
*/


void FaceMovementDirection (AActor *);
